%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Curso de Teoría y Práctica Elementos Finitos
% Posgrado en Matematicas-UNAM-CdMx
% Prof. Daniel Castañon Quiroz. daniel.castanon@iimas.unam.mx
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Descripcion:
%           Importa una malla previamente creada usando el programa
%           gmsh. Esta malla se guarada en un archivo matlab .m
%           Gráfica una funcion evaluada en los nodos de la malla
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


msh=read_mesh('square_3.m'); %importa  estructura msh
%Imprime en pantalla lo que contiene la variable/estructura msh
msh;

%Funcion a graficar
f_x_y=@f_exact; % Declaracion de una funcion handler (Gilat Ch 7)
z=f_x_y(msh.nodes(:,1),msh.nodes(:,2));
%---- graficar ---------------------
 figure(1)
 %Grafica la malla
 trimesh(msh.elems_nodes_conn(:,1:3),msh.nodes(:,1),msh.nodes(:,2),z);
 xlabel('X','fontsize',14)
 ylabel('Y','fontsize',14)
 title('GMsh to MATLAB import','fontsize',14)

%--------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------------------------------------------------------------
function [val] = f_exact(x,y)

    val=(x-0.5).^2 + (y-0.5).^2; % evalua en cada nodo de la malla
end
