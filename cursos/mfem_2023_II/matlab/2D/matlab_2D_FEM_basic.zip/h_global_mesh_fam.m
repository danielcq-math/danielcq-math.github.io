%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Curso de Teoría y Práctica Elementos Finitos
% Posgrado en Matematicas-UNAM-CdMx
% Prof. Daniel Castañon Quiroz. daniel.castanon@iimas.unam.mx
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Descripcion:
%           Importa una serie malla previamente creadas usando el programa
%           gmsh. Esta malla se guarada en un archivo matlab .m
%           Para cada malla calcula su h_global (i.e., el diamétro máximo
%           de sus celdas)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



msh_filenames = ["square_1.m" "square_2.m" "square_3.m"...
                 "square_4.m" "square_5.m" "square_6.m"];

for i=1:6
 msh=read_mesh(msh_filenames(i));
 get_h_global(msh); %importa variable msh
 
 disp("El valor de h_global para la malla contenida en el archivo...es"); %Imprime en la terminal   
 h_global=get_h_global(msh);
 disp(h_global);

end