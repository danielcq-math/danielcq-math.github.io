Scripts de matlab (para correr)

1) read_and_plot_mesh.m : Importa un malla y gráfica sus simplejos y vértices.
2) plot_f_mesh.m:  Importa un malla y gráfica una función sobre esta malla.
3) get_h_global_mesh_fam.m: Dada un familia de mallas, cácula su tamaño de malla h para cada una e imprime su valor.



Archivos de mallas:

square_1.m
square_2.m
square_3.m
square_4.m
square_5.m
