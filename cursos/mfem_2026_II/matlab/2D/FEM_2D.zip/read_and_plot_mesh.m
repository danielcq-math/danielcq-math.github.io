%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Curso de Teoría y Práctica Elementos Finitos
% Posgrado en Matematicas-UNAM-CdMx
% Prof. Daniel Castañon Quiroz. daniel.castanon@iimas.unam.mx
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Descripcion:
%           Importa una malla (2D) previamente creada usando el programa
%           gmsh. Esta malla se guarada en un archivo matlab .m
%           Gráfica la malla
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

msh=read_mesh('square_2.m'); %importa  estructura msh
%Imprime en pantalla lo que contiene la variable/estructura msh
msh

%---- graficar ---------------------
 figure(1)
 %Grafica la malla
 triplot(msh.elems_nodes_conn(:,1:3),msh.nodes(:,1),msh.nodes(:,2));
 xlabel('X','fontsize',14)
 ylabel('Y','fontsize',14)
 title('GMsh to MATLAB import','fontsize',14)


 hold on
 figure(1)
%% Grafica los nodos de la malla que estan en la frontera usando onodes_bool
plot(msh.nodes(msh.onodes_bool,1),msh.nodes(msh.onodes_bool,2), '*r');

 %% Grafica los nodos de la malla que estan en la frontera
 %% utilizando ofaces_nodes_conn
 %plot(msh.nodes(msh.ofaces_nodes_conn(:,1),1),msh.nodes(msh.ofaces_nodes_conn(:,1),2),'*r'...
 %    ,msh.nodes(msh.ofaces_nodes_conn(:,2),1),msh.nodes(msh.ofaces_nodes_conn(:,2),2),'*r');

hold off
 


